# A golden crown

total alphabets number 

number_of_alphabets = 26

min_allies_support = 3


kingdoms = {
    'SPACE':'GORILLA',
    'LAND':'PANDA',
    'WATER':'OCTOPUS',
    'ICE':'MAMMOTH',
    'AIR':'OWL',
    'FIRE':'DRAGON'
}